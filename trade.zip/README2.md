Coisini 核心主流:
30 09 * * * /usr/bin/python3 /root/test_trade/tes_go.py >> /root/test_trade/tes_go.log 2>&1

Coisini 核心主流:
nohup streamlit run trade_me.py --server.port 8051 --server.enableCORS false --server.enableXsrfProtection false &


pip install requests streamlit plotly pandas pymysql matplotlib beautifulsoup4 urllib3