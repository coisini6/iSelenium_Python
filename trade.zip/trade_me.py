from datetime import datetime, timedelta
import requests
import streamlit as st
import plotly.graph_objects as go
import csv
import pandas as pd
import pymysql
import matplotlib.pyplot as plt
from collections import Counter
from plotly.subplots import make_subplots
from bs4 import BeautifulSoup
# from cc import fetch_data  # 不再需要导入

# 常量定义
BASE_URL = "https://api.fupanwang.com/xgb"
QINGXU_URL = "https://api.fupanwang.com/vip/qingxu_list2?num=30"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36"

# 工具函数

def fetch_json(url: str, method: str = "get", headers=None, data=None, params=None):
    """
    通用网络请求工具，返回json或None
    """
    try:
        if method == "get":
            resp = requests.get(url, headers=headers, params=params, timeout=10)
        else:
            resp = requests.post(url, headers=headers, json=data, timeout=10)
        return resp.json()
    except Exception as e:
        st.error(f"请求失败: {url}, 错误: {e}")
        return None

def get_recent_weekdays(n: int = 10) -> list:
    """
    获取最近n个工作日日期列表
    """
    today = datetime.now()
    weekdays = []
    if today.weekday() < 5:
        weekdays.append(today.strftime('%Y-%m-%d'))
    while len(weekdays) < n:
        today -= timedelta(days=1)
        if today.weekday() < 5:
            weekdays.append(today.strftime('%Y-%m-%d'))
    return weekdays

def show_styled_table(df: pd.DataFrame):
    styled_df = df.style.set_table_styles(
        [{'selector': 'td', 'props': [('white-space', 'nowrap'), ('font-size', '16px'), ('font-weight', 'bold')]}]
    )
    st.markdown(styled_df.to_html(), unsafe_allow_html=True)

class TradeMe:
    def __init__(self):
        """
        初始化 TradeMe 类，设置 API 地址和请求头。
        """
        self.base_url = BASE_URL
        self.qingxu_url = QINGXU_URL
        self.headers = {"User-Agent": USER_AGENT}

    def get_hot(self):
        """
        获取近10个工作日的热门板块数据，并以表格形式展示。
        """
        weekdays = get_recent_weekdays(7)
        hot_dict = {}
        for date_str in weekdays:
            if date_str == datetime.now().strftime('%Y-%m-%d'):
                continue
            hot_url = f"{self.base_url}/hot?date={date_str}"
            data = fetch_json(hot_url, headers=self.headers)
            if not data or not data.get('data') or not data["data"].get('ticai'):
                continue
            sector_list = [f"{sector['plate_name']}  :  {sector['plate_topnum']}" for sector in data["data"]['ticai'] if "ST" not in sector["plate_name"] and int(sector["plate_topnum"]) >= 2]
            hot_dict[date_str] = sector_list
        if hot_dict:
            max_length = max(len(v) for v in hot_dict.values())
            for key in hot_dict:
                while len(hot_dict[key]) < max_length:
                    hot_dict[key].append(None)
            df = pd.DataFrame(hot_dict)
            show_styled_table(df)

    def show_market_summary(self, date_str: str):
        """
        展示指定日期的大盘数据。
        :param date_str: 日期字符串，格式为 'YYYY-MM-DD'
        """
        fupan_url = f"{self.base_url}/fupan?date={date_str}"
        market_data = fetch_json(fupan_url, headers=self.headers)
        if not market_data or not market_data.get('data'):
            return
        data = market_data['data']
        huzhi = data.get("sh_rate", 0)
        shenzhi = data.get("sz_rate", 0)
        chuanyeban = data.get("cyb_rate", 0)
        bankuaier = data.get("zhuxian", [{}])[0].get("plate_name", "")
        ban = data.get("top_num", 0)
        dieting = data.get("bottom_num", 0)
        zhaban = data.get("open_num", 0)
        lianban = data.get("continue_top_num", 0)
        zhang = data.get("up_num", 0)
        fengbanlv = data.get("top_rate", 0)
        die = data.get("down_num", 0)
        liang = data.get("amount", 0)
        long = data.get("long_name", "")
        longban = data.get("long_ban", 0)
        liangzengjian = data.get("diff_amount", 0)
        liangzengjian_str = f"{int(liangzengjian)}亿 ↑" if int(liangzengjian) > 0 else f"{int(liangzengjian)}亿 ↓"
        huzhi_color = "red" if huzhi >= 0 else "green"
        shenzhi_color = "red" if shenzhi >= 0 else "green"
        chuanyeban_color = "red" if chuanyeban >= 0 else "green"
        st.header(date_str)
        html_table = f"""
            <style>
            table {{ width: 100%; margin: auto; border-collapse: collapse; text-align: center; font-size: 20px; font-weight: bold; }}
            table, td {{ text-align: center; font-size: 20px; font-weight: bold; }}
            table, td {{ border: 1px solid black; padding: 8px; }}
            td {{ background-color: #f9f9f9; }}
            .red-text {{ color: red; }}
            .green-text {{ color: green; }}
            </style>
            <table>
                <tr>
                    <td style="color: {huzhi_color};">沪指：{huzhi}%</td>
                    <td style="color: {shenzhi_color};">深指：{shenzhi}%</td>
                    <td style="color: {chuanyeban_color};">创业板：{chuanyeban}%</td>
                    <td>量能：{liang}亿 : {liangzengjian_str}</td>
                </tr>
                <tr>
                    <td class="red-text" >涨停：{ban}</td>
                    <td class="green-text" >跌停：{dieting}</td>
                    <td>炸板数：{zhaban}</td>
                    <td>连扳数：{lianban}</td>
                </tr>
                <tr>
                    <td class="red-text" >上涨数量：{zhang}</td>
                    <td class="green-text">下跌数量：{die}</td>
                    <td class="red-text" colspan="2">封板率：{fengbanlv}%</td>
                </tr>
                <tr>
                    <td class="red-text" colspan="4">连板高度：{longban} 板：{long} : {bankuaier}</td>
                </tr>
            </table>
            """
        st.markdown(html_table, unsafe_allow_html=True)

    def show_rankings(self):
        """
        展示当前热度排行。
        """
        url = "https://emappdata.eastmoney.com/stockrank/getAllCurrentList"
        datas = {"appId": "appId01", "globalId": "786e4c21-70dc-435a-93bb-38", "marketType": "", "pageNo": 1, "pageSize": 10}
        stock_data = fetch_json(url, method="post", headers=self.headers, data=datas)
        if not stock_data or not stock_data.get('data'):
            return
        secids = ','.join([item['sc'] for item in stock_data['data']])
        secids = secids.replace("SZ", "0.").replace('SH', '1.')
        url2 = f'https://push2.eastmoney.com/api/qt/ulist.np/get?fields=f14&secids={secids}'
        hot_data = fetch_json(url2, headers=self.headers)
        if not hot_data or not hot_data.get('data') or not hot_data['data'].get('diff'):
            return
        hot_list = [item['f14'] for item in hot_data['data']['diff']]
        df = pd.DataFrame(hot_list, columns=['热度']).T
        show_styled_table(df)

    def show_sector(self):
        """
        展示今日热门板块及其成分股。
        """
        today = datetime.now().date()
        hot_url = f"{self.base_url}/hot?date={today}"
        try:
            response = requests.get(hot_url, headers=self.headers)
            data = response.json()
        except Exception as e:
            return
        if not data.get("data") or not data["data"].get('ticai'):
            return
        for sector in data["data"]['ticai']:
            stock_list = []
            if "ST" not in sector["plate_name"] and int(sector["plate_topnum"]) >= 2 and len(sector['stock']) > 0:
                st.markdown(f"""
                    <div style="font-size:25px;"><strong>{sector['plate_name']}</strong></div>
                    """, unsafe_allow_html=True)
                if sector['plate_reason']:
                    st.markdown(f"""
                    <div style="font-size:20px; color:red;">{sector['plate_reason']}</strong></div>
                    <div style="font-size:20px; color:red;">
                    <br>
                    </div>
                    """, unsafe_allow_html=True)
                else:
                    st.markdown(f"""
                    <div style="font-size:20px; color:red;">
                    <br>
                    </div>
                    """, unsafe_allow_html=True)
                for stock in sector['stock']:
                    stock_list.append({"stock_name": stock['stock_name'], "stock_day_top": stock['stock_day_top']})
                if stock_list:
                    line = ""
                    for index, stock in enumerate(stock_list):
                        if stock['stock_day_top']:
                            stock_display = f"<span  style='display: inline-block; border: 2px solid #d3d3d3;  background-color:  transparent; padding: 3px 7px;border-radius: 5px;color: #000;font-size:19px; vertical-align:middle;margin-right:2px;'> {stock['stock_name']}</span>\t<span style='color:red; font-size:16px; vertical-align:middle;margin-right:20px;'><strong>{stock['stock_day_top']}</strong></span>"
                        else:
                            stock_display = f"<span  style='display: inline-block; border: 2px solid #d3d3d3;  background-color:  transparent; padding: 3px 7px;border-radius: 5px;color: #000;font-size:19px; vertical-align:middle;margin-right:2px;'> {stock['stock_name']}</span>"
                        line += stock_display
                        if (index + 1) % 4 == 0:
                            st.markdown(line, unsafe_allow_html=True)
                            line = ""
                        else:
                            line += "\t"
                    st.markdown(line, unsafe_allow_html=True)

    def show_consecutive_boards(self):
        """
        展示今日连板数及其成分股。
        """
        today = datetime.now().date()
        lianban_url = f"{self.base_url}/lianban?date={today}"
        try:
            response = requests.get(lianban_url, headers=self.headers)
            data = response.json()
        except Exception as e:
            return
        if not data.get('data'):
            return
        for item in data["data"]['list']:
            stock_list = []
            if item['list']:
                num = len(item['list'])
                st.markdown(f"""
                            <div style="font-size:30px;"><strong>{item['name']}:{num}</strong></div>
                            <div style="font-size:20px; color:red;">
                            <br>
                            </div>
                            """, unsafe_allow_html=True)
                for stock in item['list']:
                    stock_list.append({"stock_name": stock['stock_name'], "plates": stock['plates']})
                stock_list = sorted(stock_list, key=lambda x: x['plates'])
                if stock_list:
                    line = ""
                    for index, stock in enumerate(stock_list):
                        stock_display = f"<span style='font-size:23px; vertical-align:middle;margin-right:2px;'> {stock['stock_name']}</span>\t<span style='display: inline-block; border: 2px solid #f00;  background-color:   #ffe6e6; padding: 2px 5px;border-radius: 3px;color: #000;font-size:18px; vertical-align:middle;margin-right:30px;'>{stock['plates']}</span>"
                        line += stock_display
                        if (index + 1) % 2 == 0:
                            st.markdown(line, unsafe_allow_html=True)
                            line = ""
                    st.markdown(line, unsafe_allow_html=True)
              
    def plot_limit_up_trend(self):
        """
        读取合并后的CSV文件，绘制近20日涨停趋势折线图。
        """
        try:
            with open('daily_combined_data.csv', mode='r', encoding='utf-8') as file:
                reader = csv.reader(file)
                data = list(reader)[1:]  # 跳过表头
                data = data[-20:]  # 取最近20条记录
        except Exception as e:
            st.error(f"读取daily_combined_data.csv文件时出错: {e}")
            return
            
        if len(data) > 0:
            # 新的表结构: [日期, 最高连板天数, 股票名称, 情绪数据]
            dates = []
            limit_up_days = []
            stock_names = []
            
            for row in data:
                if len(row) > 2 and row[1].isdigit():
                    # 只保留日期部分，去除时间信息
                    date_str = row[0].split(' ')[0] if ' ' in row[0] else row[0]
                    dates.append(date_str)
                    limit_up_days.append(int(row[1]))
                    stock_names.append(row[2])
            
            if len(dates) > 0 and len(limit_up_days) > 0:
                fig = go.Figure()
                fig.add_trace(go.Scatter(
                    x=dates,
                    y=limit_up_days,
                    mode='lines+markers+text',
                    text=stock_names,
                    textposition='top right',
                    marker=dict(size=5, color='red'),
                    line=dict(color='blue')
                ))
                
                # 设置x轴格式为日期格式，不显示时间
                fig.update_xaxes(
                    showgrid=True, 
                    linecolor='black', 
                    linewidth=1, 
                    tickmode='auto', 
                    ticks='outside',
                    tickformat='%Y-%m-%d',  # 只显示日期
                    tickangle=45  # 旋转45度以便更好显示
                )
                fig.update_yaxes(showgrid=True, linecolor='black', linewidth=1, tickmode='linear', ticks='outside', dtick=1, range=[0, 16], tick0=0)
                fig.show()
                st.plotly_chart(fig)
            else:
                st.warning("没有可显示的数据")
    
    def show_limit_up_and_sector(self):
        """
        展示连板数和板块统计。
        """
        # 从fupan.csv文件读取数据
        try:
            # 读取fupan.csv文件
            df = pd.read_csv('fupan.csv')
            # 只解析日期部分，不包含时间
            df['日期'] = pd.to_datetime(df['日期']).dt.date
            # 只取最近20条记录
            df = df.tail(20)
            
            # 创建子图
            fig = make_subplots(rows=2, cols=1, subplot_titles=("日期 vs 高度和指数", "日期 vs 上涨数量"))
            # 第一个子图：高度和指数
            fig.add_trace(
                go.Scatter(x=df['日期'], y=df['高度'], mode='lines+markers', name='高度', line=dict(color='red')),
                row=1, col=1
            )
            fig.add_trace(
                go.Bar(x=df['日期'], y=df['指数'], name='指数', marker=dict(color='blue', opacity=0.6)),
                row=1, col=1
            )
            fig.add_hline(y=0, line=dict(color='black', width=0.8), row=1, col=1)
            # 第二个子图：上涨家数
            fig.add_trace(
                go.Scatter(x=df['日期'], y=df['上涨家数'], mode='lines+markers', name='上涨数量', line=dict(color='green')),
                row=2, col=1
            )
            
            # 设置x轴格式为日期格式，不显示时间
            fig.update_xaxes(
                tickformat='%Y-%m-%d',  # 只显示日期
                dtick='D1',  # 按天显示刻度
                tickangle=45,  # 旋转45度以便更好显示
                row=1, col=1
            )
            fig.update_xaxes(
                tickformat='%Y-%m-%d',
                dtick='D1',
                tickangle=45,
                row=2, col=1
            )
            
            fig.update_layout(height=800, width=1000, title_text="市场数据可视化", showlegend=True)
            fig.update_yaxes(title_text="高度", row=1, col=1, title_font=dict(color='red'))
            fig.update_yaxes(title_text="指数", row=1, col=2, title_font=dict(color='blue'))
            fig.update_yaxes(title_text="上涨数量", row=2, col=1, title_font=dict(color='green'))
            st.plotly_chart(fig)
        except Exception as e:
            st.error(f"读取fupan.csv文件时出错: {e}")
            
        # 获取连板股票和板块统计
        url = 'https://flash-api.xuangubao.com.cn/api/surge_stock/stocks?normal=true&uplimit=true'
        try:
            response = requests.get(url)
            data = response.json()['data']['items']
        except Exception as e:
            return
        names = []
        limit_up_list = []
        for item in data:
            if item[11] != '' and 'ST' not in item[1]:
                limit_up_list.append(item)
            names.append(item[8][0]['name'])
        def extract_middle_number(s):
            # 提取"天"和"板"之间的数字
            return int(s.split('天')[1].replace('板', ''))
        limit_up_list.sort(key=lambda x: extract_middle_number(x[11]), reverse=True)
        st.header('连扳数')
        for item in limit_up_list:
            st.markdown(f"{item[11]}, {item[1]}, {item[8][0]['name']}")
        name_counts = Counter(names)
        sorted_by_count = sorted(name_counts.items(), key=lambda x: x[1], reverse=True)
        st.header('板块数')
        for name, count in sorted_by_count:
            if count > 2:
                st.markdown(f"<span style='font-size: 24px; color: red;'>{name}: {count}次</span>", unsafe_allow_html=True)
                if count < 5 or name == 'ST股':
                    continue
                stock_names = [item[1] for item in data if item[8][0]['name'] == name]
                st.markdown(stock_names)
          
    def ttt(self):
        """
        读取合并后的CSV文件中的历史情绪数据并以表格形式展示
        """
        st.header("📈 历史情绪数据")
        
        try:
            with open('daily_combined_data.csv', mode='r', encoding='utf-8') as file:
                reader = csv.reader(file)
                data_list = list(reader)[1:]  # 跳过表头
                
            if len(data_list) > 0:
                # 将数据转换为DataFrame格式
                all_data = []
                for row in data_list[-5:]:  # 只显示最近5条记录
                    if len(row) >= 4:  # 新表结构有4列
                        date = row[0]
                        emotion_str = row[3]
                        
                        # 只保留日期和情绪数据
                        data_dict = {"日期": date}
                        
                        # 解析情绪数据
                        if emotion_str and emotion_str != "":
                            pairs = emotion_str.split(", ")
                            for pair in pairs:
                                if ": " in pair:
                                    key, value = pair.split(": ", 1)
                                    data_dict[key] = value
                        
                        all_data.append(data_dict)
                
                if all_data:
                    # 创建DataFrame
                    df = pd.DataFrame(all_data)
                    
                    # 使用样式化的HTML表格
                    st.markdown("### 情绪数据表格展示")
                    
                    # 应用样式 - 对"昨炸板表现%"列进行特殊处理
                    styled_df = df.style
                    
                    if '昨炸板表现%' in df.columns:
                        styled_df = styled_df.map(
                            lambda x: 'color: green' if isinstance(x, str) and x.startswith('-') else 'color: red',
                            subset=pd.IndexSlice[:, ['昨炸板表现%']]
                        )
                    
                    # 对其他所有情绪数值列应用红色（除了日期和炸板表现%）
                    for col in df.columns:
                        if col not in ['日期', '昨炸板表现%']:
                            styled_df = styled_df.map(
                                lambda x: 'color: red',
                                subset=pd.IndexSlice[:, [col]]
                            )
                    
                    # 显示样式化表格
                    st.write(styled_df.to_html(escape=False), unsafe_allow_html=True)
                else:
                    st.warning("没有可显示的数据")
            else:
                st.warning("CSV文件中没有数据")
        except Exception as e:
            st.error(f"读取daily_combined_data.csv文件时出错: {e}")
    
    def fetch_data(self):
        """
        从复盘网获取市场情绪数据。
        """
        url = "https://www.fupanwang.com/qingxu/"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        }
        try:
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()  # 如果请求失败则引发HTTPError
            response.encoding = response.apparent_encoding
            soup = BeautifulSoup(response.text, "html.parser")

            container = soup.find("div", class_=lambda c: c and "my-gray" in c)

            if container:
                lines = container.decode_contents().split("<br>")
                data = {}
                for line in lines:
                    line_soup = BeautifulSoup(line, "html.parser")
                    texts = list(line_soup.stripped_strings)
                    for i in range(0, len(texts) - 1, 2):
                        key = texts[i].strip().rstrip("：::")
                        value = texts[i + 1].strip()
                        data[key] = value

                keys = [
                    "1进2晋级", "2进3晋级", "高度板晋级",
                    "炸板%", "昨涨表现%", "昨连板表现%", "昨炸板表现%"
                ]

                today = datetime.today().strftime("%Y-%m-%d")
                
                return data, keys, today
            else:
                return None, None, None
        except requests.RequestException:
            # 发生网络请求错误时，返回None，避免打印
            return None, None, None
    def show_qingxu_data(self):
        """
        调用cc.py的fetch_data方法获取情绪数据并使用表格展示
        """
        st.header("📊 情绪指标")
        
        data, keys, today = self.fetch_data()
        
        if data:
            st.markdown(f"### 情绪指标数据 (日期: {today})")
            
            # 创建一个单行的DataFrame，每个指标作为一列
            data_dict = {"日期": today}
            for key in keys:
                data_dict[key] = data.get(key, "未找到")
            
            # 创建DataFrame - 只有一行，每个指标是一列
            df = pd.DataFrame([data_dict])
            df = df.tail(5) 
            # 使用样式化的HTML表格
            st.markdown("### 情绪指标表格")
            
            # 应用样式 - 对"昨炸板表现%"列进行特殊处理
            styled_df = df.style.map(
                lambda x: 'color: green' if isinstance(x, str) and x.startswith('-') else 'color: red',
                subset=pd.IndexSlice[:, ['昨炸板表现%']] if '昨炸板表现%' in df.columns else None
            )
            
            # 对其他所有数值列应用红色
            for col in df.columns:
                if col != '日期' and col != '昨炸板表现%':
                    styled_df = styled_df.map(
                        lambda x: 'color: red',
                        subset=pd.IndexSlice[:, [col]]
                    )
            
            # 显示样式化表格
            st.write(styled_df.to_html(escape=False), unsafe_allow_html=True)
        else:
            st.error("❌ 无法获取情绪数据")
        
if __name__ == '__main__':
    # st.set_page_config(layout="wide")
    plt.rcParams['font.sans-serif'] = ['SimHei']  # 设置字体为 SimHei（黑体）
    plt.rcParams['axes.unicode_minus'] = False   # 解决负号显示问题
    app = TradeMe()
    st.title("复盘")
    st.markdown(
        "<h1 style='color: red; font-size: 40px;'> 指数+时机（情绪周期+赚钱效应）+题材+板块效应+核心股 + 资金驱动 </h1>",
        unsafe_allow_html=True
    )
    weekdays = get_recent_weekdays(5)
    for date_str in reversed(weekdays):
        if date_str == datetime.now().strftime('%Y-%m-%d'):
            continue
        app.show_market_summary(date_str)
    app.plot_limit_up_trend()
    app.show_limit_up_and_sector()
    app.get_hot()
    app.show_rankings()
    app.ttt()
    app.show_qingxu_data()
    # app.show_sector()
    # app.show_consecutive_boards()
    
